import kaboom from "kaboom"

// initialize context
kaboom({
  font: "sink",
  background: [225, 225, 225]
})

//load all assests
loadSprite("player", "sprites/player.png");
loadSprite("enemy", "sprites/enemy.png");
loadSprite("apple", "sprites/apple.png");
// lets add sound
loadSound("score", "sounds/score.mp3");
loadSound("bug", "sounds/bug.mp3");

//lets difine variables
let SPEED = 320
let ESPEED = 2
let score = 0
let scoreText;
let gamestop = false
let highscore =0

//Intro
scene("intro", () => {
  add([
    text("Press 'SPACE' to start the game"),
    scale(4),
    color(242, 10, 10),
    pos(250, 250)
  ])
  onKeyPress("space", () => {
    go("game")
  })
})
go("intro")

// Game screen
scene("game", () => {


  const displayscore = () => {
    destroy(scoreText)
    scoreText = add([
      text("Score: " + score),
      scale(3),
      pos(21, 21),
      color(255, 17, 0)
    ])
  }
  //lets add the programmer
  const player = add([
    sprite("player"),  // renders as a sprite
    pos(120, 320),    // position in world
    area(),          // has a collider
    scale(0.13),
  ])

  //let difine controles
  onKeyDown("left", () => {
    player.move(-SPEED, 0)
  })
  onKeyDown("right", () => {
    player.move(SPEED, 0)
  })
  onKeyDown("up", () => {
    player.move(0, -SPEED)
  })
  onKeyDown("down", () => {
    player.move(0, SPEED)
  })

  onKeyPress("p", () => {
    if (gamestop == false) {
      SPEED = 0
      ESPEED = 0
      gamestop = true
    }
    else {
      gamestop = false
      SPEED = 320
      ESPEED = 2

    }
  })

  //let add enemy in game
  loop(2, () => {
    for (let i = 0; i < 4; i++) {

      let enemy = add([
        sprite("enemy", solid),
        pos(width(), rand(50, 600)),
        area(),
        scale(0.5),
        "enemy"
      ])
      enemy.onUpdate(() => {
        enemy.moveTo(enemy.pos.x - ESPEED, enemy.pos.y)
      })
    }
    let apple = add([
      sprite("apple", solid),
      pos(width(), rand(100, 600)),
      area(),
      scale(0.7),
      "apple"
    ])
    apple.onUpdate(() => {
      apple.moveTo(apple.pos.x - ESPEED, apple.pos.y)
    })
  
  })

  player.onCollide("enemy", () => {
    destroy(player)
    addKaboom(player.pos)
    play("bug")
    ESPEED = 0
    go("gameover")
  })
  player.onCollide("apple", (apple) => {
    play("score")
    score += 1
    destroy(apple)
    displayscore()
    
      if (ESPEED < 15){
      ESPEED += 1
    }
     if(highscore<score){
    highscore=score
  }
  })
 

  //display the score
  displayscore()

})

// Game over screen
scene("gameover", () => {
  add([
    text("Game Over \n\nScore:" + score+"\n\nHigh score:"+highscore),
    scale(5),
    pos(500, 250),
    color(255, 17, 0),
  ])
  add([
    text("Press 'SPACE' to Restart the game"),
    scale(5),
    pos(150, 500),
    color(255, 17, 0),
  ])
  onKeyPress("space", () => {
    go("game")
    ESPEED = 2
    score = 0
  })
}
)

